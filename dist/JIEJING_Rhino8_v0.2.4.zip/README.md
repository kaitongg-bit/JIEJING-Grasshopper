# JIEJING Grasshopper plug-in — Rhino 8 v0.2.4

## Install

1. Close Rhino 8.
2. Use the `.yak` file in `build/rh8/` for Package Manager submission, or copy
   `build/rh8/JIEJING.Components.gha` into Grasshopper's `Libraries` folder.
3. Reopen Rhino and Grasshopper. Find **JIEJING** in the JIEJING tab.
4. On first use, Rhino's Python 3 package manager installs the declared local
   geometry dependencies (`numpy`, `opencv-python-headless`, `pillow`, `ezdxf`,
   and `reportlab`). No API key is needed.

The installed components are self-contained: their `jiejing` Python library and 14
curated recipes are embedded in the GHA. It does not depend on this repository,
an external virtual environment, Stable Diffusion, or a paid service.

## Components

The JIEJING tab contains eight components plus four ready-made selectors in
three readable toolbar panels:

- **Design** — Quick Generate, Window, Pattern, Borrowed View, Image Field
- **Make** — Compose, Material Preview, Export
- **Selectors** — four preconfigured Grasshopper Value Lists for Recipe,
  View Shape, Image Mode, and Polarity

Components:

- `Quick Generate`: the original one-component beginner workflow.
- `Window`: validates a closed World XY window boundary.
- `Pattern`: recipe, density, lattice weight, and frame weight.
- `Borrowed View`: optional opening, profile/custom guide, position, and amount.
- `Image Field`: optional non-AI portrait, pet, silhouette, or cartoon control.
- `Compose`: combines the four modular inputs into closed fabrication curves.
- `Material Preview`: creates planar black material regions.
- `Export`: writes 1:1 millimetre DXF, SVG, and PDF files when Trigger is true.

All categorical modular inputs use built-in named choices rather than internal
text codes. Right-click `Recipe`, `Shape`, `Mode`, or `Polarity` to choose from
the bilingual menu. Every optional input also ships with a safe default. The
Starter file exposes the same choices as visible value lists and toggles.

## Starter files

- Open `JIEJING_Baby_Starter.gh` first if you are new to Grasshopper. It opens
  with a sample window, all wires connected, bilingual instructions, safe
  defaults, visible dropdowns, optional borrowed-view/image controls, a material
  preview, and an export switch that is off by default. The image section has a
  prewired **IMAGE FILE** input: right-click it and choose **Select one existing
  file** to browse for a JPG or PNG. Users never need to type or paste a path
  into a Panel. Changing the window sliders or recipe list recomputes the result
  immediately.
- Open `JIEJING_Modular_Starter.gh` when you want to rebuild or extend the graph.
  Its normal workflow is
  `Window + Pattern + Borrowed View + Image Field -> Compose`, followed by
  `Material Preview` and/or `Export`.

It outputs closed Rhino curves. Each solve also writes DXF, 1:1 PDF, SVG, PNG,
and a JSON report to `~/Documents/JIEJING_exports/`.

The four `.ghuser` files in `user_objects/` are optional toolbar selectors.
Copy them to Grasshopper's `UserObjects` folder (the local installer already
does this). After restarting Rhino they appear under **JIEJING > Selectors**
and can be dragged directly onto the canvas as ready-made dropdown lists.

## Build

The package follows McNeel's Rhino 8 Script Editor project format:

```text
/Applications/Rhino 8.app/Contents/Resources/bin/rhinocode project build \
  JIEJING.rhproj --buildversion 0.2.4 --buildtarget '8.*' --buildpath build
```

The installed integration test registers all eight components, connects the
modular workflow, generates 121 closed curves from a 600 x 400 mm test window,
creates a planar material preview, and exports DXF, SVG, and PDF without errors.

